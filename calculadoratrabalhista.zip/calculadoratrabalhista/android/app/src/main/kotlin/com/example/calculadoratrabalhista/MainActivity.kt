package com.example.calculadoratrabalhista

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
