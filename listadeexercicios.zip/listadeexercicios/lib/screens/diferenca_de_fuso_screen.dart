import 'package:flutter/material.dart';

import '/models/resultado_diferenca_de_fuso.dart';

class DiferencaDeFusoScreen extends StatefulWidget {
  const DiferencaDeFusoScreen({super.key});

  @override
  State<DiferencaDeFusoScreen> createState() => _DiferencaDeFusoScreenState();
}

class _DiferencaDeFusoScreenState extends State<DiferencaDeFusoScreen> {
  String resultado = '';
  final _formKey = GlobalKey<FormState>();
  final _fusoOrigemController = TextEditingController();
  final _fusoDestinoController = TextEditingController();

  void atualizarResultado() {
    final resultadoContagem = ResultadoDiferencaDeFuso(
      fusoOrigem: _fusoOrigemController.text.trim(),
      fusoDestino: _fusoDestinoController.text.trim(),
    );
    setState(() {
      resultado = resultadoContagem.calcularDiferencaDeFuso();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora de Diferença de Fuso Horário'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text(
                'Insira os fusos horários para calcular a diferença:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _fusoOrigemController,
                decoration: const InputDecoration(
                  labelText: 'Fuso de Origem (ex: UTC-3)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Por favor, insira o fuso de origem';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _fusoDestinoController,
                decoration: const InputDecoration(
                  labelText: 'Fuso de Destino (ex: UTC+2)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Por favor, insira o fuso de destino';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    atualizarResultado();
                  }
                },
                child: const Text('Calcular'),
              ),
              if (resultado.isNotEmpty) ...[
                const SizedBox(height: 24),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      resultado,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
