import 'package:flutter/material.dart';
import '/screens/contagem_regressiva_para_screen.dart';
import '/screens/diferenca_de_fuso_screen.dart';
import '/screens/tempo_restante_ate_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lista 15')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Escolha a calculadora que deseja utilizar:',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor:
                      Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ContagemRegressivaParaScreen(),
                    ),
                  );
                },
                child: const Text('Calculadora de contagem regressiva para o evento'),
              ),

              SizedBox(height: 20),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor:
                      Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const DiferencaDeFusoScreen(),
                    ),
                  );
                },
                child: const Text('Calculadora de diferença de fuso horário'),
              ),

              SizedBox(height: 20),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor:
                      Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TempoRestanteAteScreen(),
                    ),
                  );
                },
                child: const Text(
                  'Calculadora de tempo restante até a aposentadoria',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
