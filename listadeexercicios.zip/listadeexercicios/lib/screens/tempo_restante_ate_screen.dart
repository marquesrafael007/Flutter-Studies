import 'package:flutter/material.dart';

import '/models/resultado_tempo_restante_ate.dart';

class TempoRestanteAteScreen extends StatefulWidget {
  const TempoRestanteAteScreen({super.key});

  @override
  State<TempoRestanteAteScreen> createState() => _TempoRestanteAteScreenState();
}

class _TempoRestanteAteScreenState extends State<TempoRestanteAteScreen> {
  final _formKey = GlobalKey<FormState>();
  final _idadeAtualController = TextEditingController();
  final _idadeDesejadaController = TextEditingController();
  String resultado = '';

  void atualizarResultado() {
    final idadeAtual = int.tryParse(_idadeAtualController.text);
    final idadeDesejada = int.tryParse(_idadeDesejadaController.text);

    if (idadeAtual == null || idadeDesejada == null) {
      setState(() {
        resultado = 'Informe valores numéricos válidos.';
      });
      return;
    }

    final calculo = ResultadoTempoRestanteAte(
      idadeAtual: idadeAtual,
      idadeDesejada: idadeDesejada,
    );

    setState(() {
      resultado = calculo.calcularTempoRestante();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora de Tempo Restante até a Aposentadoria'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text(
                'Informe sua idade atual e a idade em que deseja se aposentar:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _idadeAtualController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Idade atual',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Por favor, informe a idade atual.';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Digite apenas números inteiros.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _idadeDesejadaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Idade desejada para se aposentar',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Por favor, informe a idade desejada.';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Digite apenas números inteiros.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    atualizarResultado();
                  }
                },
                child: const Text('Calcular'),
              ),
              if (resultado.isNotEmpty) ...[
                const SizedBox(height: 24),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Resultado',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(resultado, style: const TextStyle(fontSize: 16)),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
