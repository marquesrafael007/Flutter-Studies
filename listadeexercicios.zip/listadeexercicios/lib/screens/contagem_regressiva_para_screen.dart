import 'package:flutter/material.dart';

import '/models/resultado_contagem_regressiva_para.dart';

class ContagemRegressivaParaScreen extends StatefulWidget {
  const ContagemRegressivaParaScreen({super.key});

  @override
  State<ContagemRegressivaParaScreen> createState() =>
      _ContagemRegressivaParaScreenState();
}

class _ContagemRegressivaParaScreenState
    extends State<ContagemRegressivaParaScreen> {
  String resultado = '';
  final _formKey = GlobalKey<FormState>();
  final _nomeEventoController = TextEditingController();
  DateTime _dataEvento = DateTime.now();

  Future<void> _selecionarData() async {
    final dataSelecionada = await showDatePicker(
      context: context,
      initialDate: _dataEvento,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (dataSelecionada != null) {
      setState(() {
        _dataEvento = dataSelecionada;
      });
    }
  }

  void atualizarResultado() {
    final nomeEvento = _nomeEventoController.text.trim();
    final resultadoContagem = ResultadoContagemRegressivaPara(
      nomeEvento: nomeEvento,
      dataEvento: _dataEvento,
    );
    setState(() {
      resultado = resultadoContagem.calcularContagemRegressiva();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calculadora de Contagem Regressiva')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text(
                'Insira o nome do evento e a data para calcular a contagem regressiva:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _nomeEventoController,
                decoration: const InputDecoration(
                  labelText: 'Nome do Evento',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Por favor, insira o nome do evento';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ListTile(
                title: const Text('Data do evento'),
                subtitle: Text(
                  '${_dataEvento.day.toString().padLeft(2, '0')}/${_dataEvento.month.toString().padLeft(2, '0')}/${_dataEvento.year}',
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: _selecionarData,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: const BorderSide(color: Colors.grey),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    atualizarResultado();
                  }
                },
                child: const Text('Calcular'),
              ),
              if (resultado.isNotEmpty) ...[
                const SizedBox(height: 24),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      resultado,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
