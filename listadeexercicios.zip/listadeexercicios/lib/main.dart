import 'package:flutter/material.dart';
import '/screens/home_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue, useMaterial3:false),
      title: 'Lista 15',
      home: HomeScreen(),
    );
  }
}
