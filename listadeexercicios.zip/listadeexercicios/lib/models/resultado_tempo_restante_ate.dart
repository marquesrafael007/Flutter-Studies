class ResultadoTempoRestanteAte {
  final int idadeAtual;
  final int idadeDesejada;

  ResultadoTempoRestanteAte({
    required this.idadeAtual,
    required this.idadeDesejada,
  });

  int get anosRestantes => idadeDesejada - idadeAtual;
  int get mesesRestantes => anosRestantes * 12;

  String calcularTempoRestante() {
    if (idadeDesejada < idadeAtual) {
      return 'A idade desejada para aposentadoria deve ser maior que a idade atual.';
    }

    return 'Anos restantes até a aposentadoria: $anosRestantes\nMeses restantes até a aposentadoria: $mesesRestantes';
  }
}
