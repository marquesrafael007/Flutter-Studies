class ResultadoDiferencaDeFuso {
  final String fusoOrigem;
  final String fusoDestino;

  ResultadoDiferencaDeFuso({
    required this.fusoOrigem,
    required this.fusoDestino,
  });

  String calcularDiferencaDeFuso() {
    const Map<String, int> fusos = {
      'UTC-12': -12,
      'UTC-11': -11,
      'UTC-10': -10,
      'UTC-9': -9,
      'UTC-8': -8,
      'UTC-7': -7,
      'UTC-6': -6,
      'UTC-5': -5,
      'UTC-4': -4,
      'UTC-3': -3,
      'UTC-2': -2,
      'UTC-1': -1,
      'UTC+0': 0,
      'UTC+1': 1,
      'UTC+2': 2,
      'UTC+3': 3,
      'UTC+4': 4,
      'UTC+5': 5,
      'UTC+6': 6,
      'UTC+7': 7,
      'UTC+8': 8,
      'UTC+9': 9,
      'UTC+10': 10,
      'UTC+11': 11,
      'UTC+12': 12,
    };
    // Aqui você pode implementar a lógica para calcular a diferença de fuso horário
    // Por enquanto, vamos apenas retornar uma string de exemplo
    final int? origem = fusos[fusoOrigem];
    final int? destino = fusos[fusoDestino];

    if (origem == null || destino == null) {
      return 'Fuso horário inválido';
    }

    final int diferenca = destino - origem;
    return 'A diferença de fuso horário entre $fusoOrigem e $fusoDestino é de $diferenca horas.';
  }
}
