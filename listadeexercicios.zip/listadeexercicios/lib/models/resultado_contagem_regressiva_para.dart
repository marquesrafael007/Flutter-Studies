class ResultadoContagemRegressivaPara {
  final String nomeEvento;
  final DateTime dataEvento;

  ResultadoContagemRegressivaPara({
    required this.nomeEvento,
    required this.dataEvento,
  });

  String calcularContagemRegressiva() {
    final now = DateTime.now();
    final difference = dataEvento.difference(now);

    if (difference.isNegative) {
      return 'O evento "$nomeEvento" já ocorreu.';
    } else {
      final days = difference.inDays;
      final hours = difference.inHours % 24;
      final minutes = difference.inMinutes % 60;
      final seconds = difference.inSeconds % 60;

      return 'Faltam $days dias, $hours horas, $minutes minutos e $seconds segundos para o evento "$nomeEvento".';
    }
  }
}
