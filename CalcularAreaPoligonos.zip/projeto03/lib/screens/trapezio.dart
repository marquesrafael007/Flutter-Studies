import 'package:flutter/material.dart';

class ResultadoTrapezio {
  final double baseMenor;
  final double baseMaior;
  final double altura;
  final double area;

  ResultadoTrapezio({
    required this.baseMenor,
    required this.baseMaior,
    required this.altura,
    required this.area,
  });
}

class TrapezioScreen extends StatefulWidget {
  const TrapezioScreen({super.key});

  @override
  State<TrapezioScreen> createState() => _TrapezioScreenState();
}

class _TrapezioScreenState extends State<TrapezioScreen> {
  final _formKey = GlobalKey<FormState>();
  final _baseMenorController = TextEditingController();
  final _baseMaiorController = TextEditingController();
  final _alturaController = TextEditingController();

  ResultadoTrapezio? _resultado;

  void _CalcularArea(){
    if(!_formKey.currentState!.validate()) return;

    final baseMenor = double.parse(_baseMenorController.text.replaceAll(',', '.'));
    final baseMaior = double.parse(_baseMaiorController.text.replaceAll(',', '.'));
    final altura = double.parse(_alturaController.text.replaceAll(',', '.'));

    final area = ((baseMenor + baseMaior) * altura) / 2;

    setState(() {
      _resultado = ResultadoTrapezio(
        baseMenor: baseMenor,
        baseMaior: baseMaior,
        altura: altura,
        area: double.parse(area.toStringAsFixed(2)),
      );
    });
  }

  String? _validarNumero(String? valor) {
    if (valor == null || valor.isEmpty) return 'Informe um valor';
    final numero = double.tryParse(valor.replaceAll(',', '.'));
    if (numero == null || numero <= 0) {
      return 'Informe um valor numérico válido';
    }
    return null;
  }

  @override
  void dispose() {
    _baseMenorController.dispose();
    _baseMaiorController.dispose();
    _alturaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Área do Trapézio')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const Text(
                'A = (Diagonal menor . Diagonal maior) / 2',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)
              ),

              const SizedBox(height: 20),

              TextFormField(
                controller: _baseMenorController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Base menor (b)',

                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.straighten)
                ),
                validator: _validarNumero,
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller: _baseMaiorController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Base maior (B)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.height),
                ),
              ),

              const SizedBox(height: 20),

              TextFormField(
                controller: _alturaController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Altura (h)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.height),
                ),
              ),

              ElevatedButton(
                onPressed: _CalcularArea,
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: Text('Calcular', style: TextStyle(fontSize: 16)),
                ),
              ),
              const SizedBox(height: 24),
              if (_resultado != null) _buildResultado(_resultado!),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultado(ResultadoTrapezio r) {
    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Resultado',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Área'),
                Text(
                  '${r.area} un²',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.blue,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
