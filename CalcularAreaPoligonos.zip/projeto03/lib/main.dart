import 'package:flutter/material.dart';
import 'screens/triangulo.dart';
import 'screens/quadrado.dart';
import 'screens/circulo.dart';
import 'screens/retangulo.dart';
import 'screens/trapezio.dart';
import 'screens/losango.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: false),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calculadora de Áreas')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Escolha uma tela para navegar:',
                style: TextStyle(fontSize: 24),
              ),
              const SizedBox(height: 56),

              ElevatedButton(
                style: ElevatedButton.styleFrom( 
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor: Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const TrianguloScreen()),
                  );
                },
                child: const Text('Calcular Triângulo'),
              ),

              const SizedBox(height: 16),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor: Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const QuadradoScreen()),
                  );
                },
                child: const Text('Calcular Quadrado'),
              ),
  
              const SizedBox(height: 16),

              ElevatedButton(
                style: ElevatedButton.styleFrom( 
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor: Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const CirculoScreen()),
                  );
                },
                child: const Text('Calcular Círculo'),
              ),

              const SizedBox(height: 16),

              ElevatedButton(
                style: ElevatedButton.styleFrom( 
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor: Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const RetanguloScreen()),
                  );
                },
                child: const Text('Calcular Retângulo'),
              ),

              const SizedBox(height: 16),

              ElevatedButton(
                style: ElevatedButton.styleFrom( 
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor: Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const TrapezioScreen()),
                  );
                },
                child: const Text('Calcular Trapézio'),
              ),

              const SizedBox(height: 16),

              ElevatedButton(
                style: ElevatedButton.styleFrom( 
                  minimumSize: const Size(double.infinity, 50),
                  maximumSize: const Size(double.infinity, 50),
                  elevation: 8, // altura da sombra
                  shadowColor: Colors.black45,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  backgroundColor: Colors.blue, // cor de fundo
                  foregroundColor: Colors.white, // cor do texto/ícone
                  disabledBackgroundColor: Colors.grey, // cor quando desabilitado
                  disabledForegroundColor: Colors.black26,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const LosangoScreen()),
                  );
                },
                child: const Text('Calcular Losango'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
